#include <iostream>
#include <unistd.h>
#include <sstream>
#include <iomanip>
#include <sys/stat.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <fstream>
#include <string>
#include <vector>
#include <regex>
#include <unordered_map>
#include <stdio.h>
#include <ctype.h>

using namespace std;

bool parseInput(vector<string> &tokens);
bool eval(string command, vector<string> args, int fds[]);
bool evalSpecial(string command, vector<string> args);

int main(int argc, char **argv){

    //give terminal information
    cout << "Terminal created by Kevin Tang\n\n";
    cout << getcwd(nullptr, 0) << ": ";
    string input;

    //loop until user exits the shell with input exit
    while(getline(cin, input)){
        //tokenize the string , get vector of strings
        // regex r = regex("\\s+"); //tokenize by matches to regex
        // regex_token_iterator<string::iterator> rit(input.begin(), input.end(), r, -1); //split using regex iterator
        // regex_token_iterator<string::iterator> rend;
        // vector<string> tokens(rit, rend);
        
        // // stringstream ss(input);
        // // vector<string> tokens;
        // // string temp;
        // // while (ss >> quoted(temp, '\'')){
        // //     tokens.push_back(temp);
        // // }

        //push space at end of input string to help parsing conventions (it terminates at space, not end of string)
        input.push_back(' ');

        //iterate through input and create a vector of tokens
        vector<string> tokens;
        for(int i = 0; i < input.size(); i++){
            //start of new word
            string word;

            //ignore initial white space
            int j = i;
            while(isspace(input[j])){
                j++;
            }
            i = j; //start of word

            //2 cases:
            //1. j is now a quote \"
            //2. j is a regular letter
            //build word
            if(input[j] == '\'' || input[j] == '\"'){ //find end of quote
                char endFlag = input[j];
                j++;
                bool endfound = false;
                while(j < input.size()){
                    if(input[j] == endFlag && input[j - 1] != '\\'){ //make sure its not a \" , but just a '
                        endfound = true;
                        break;
                    }
                    j++;
                }

                //quote is subset of input from i to j
                if(endfound){
                    word = input.substr(i + 1, j - i - 1); //shave out start and end quotes
                    tokens.push_back(word);
                }else{
                    //print error, quotes are not closed
                    cout << "SYNTAX ERROR: quotes are open!" << endl;
                    return 0;
                }
            }else{ //regular character
                while(j < input.size()){ //find next white space or pipe or redirection
                    if(isspace(input[j])){       
                        //create the word
                        word = input.substr(i, j - i);
                        tokens.push_back(word);
                        break;

                    }else if(input[j] == '<' || input[j] == '>' || input[j] == '|'){ //add new word but also add extra words
                        //create seperate words
                        if(j-i > 0){
                            word = input.substr(i, j - i); //previous word
                            tokens.push_back(word);
                        }

                        //add the current character as its own word
                        word = input.substr(j, 1);
                        tokens.push_back(word);

                        break;
                    }
                    j++;
                }
            }

            //set i to later value of j
            i = j;

        }

        //debugging print of token parsing
        // for(auto it = tokens.begin(); tokens.end() != it; ++it){
        //     cout << (*it) << endl;
        // }

        //parse through the input and make sure its valid
        if(parseInput(tokens)){
            return 0; //exit command is detected
        }


        //prefex for next input command
        cout <<  getcwd(nullptr, 0) << ": ";
    }
    return 0;
}

//uses grammar outlined in instructions to parse commands
bool parseInput(vector<string> &tokens){
    /**GRAMMAR
     * S-> UC || UC AMP || SC
     * UC-> command_name ARGS || UC REDIRECTION filename || UC PIPE UC
     * SC-> cd DIRECTORY || exit
     * command_name-> valid executable/interpreted file name
     * AMP-> &
     * ARG-> string
     * ARGs-> ARG ARGS || ARG
     * DIRECTORY-> absolute path || relative path
     * PIPE-> |
     * REDIRECTION-> < || > 
     */

    //check last token and see if its ampersand (run process in background)

    //get sets of tokens divided by pipes
    vector< vector<string> > sets;
    int i = 0; 
    while(true){
        vector<string> set; //single set
        while(i < tokens.size() && tokens[i] != "|"){
            set.push_back(tokens[i]);
            i++;
        }
        if(set.size() > 0){
            sets.push_back(set);
        }

        i++;
        if(i >= tokens.size()){
            break;
        }
    }

    //check for special command
    int fds[2];
    pipe(fds); //connecting pipe

    //save stdout
    int stdout = dup(1);
    int stdin = dup(0);
    dup2(fds[1], 1);
    dup2(fds[0], 0);

    for(int i = 1; i < sets.size() - 1; i++){
        //check for < input text
        for(int j = 0; j < sets[i].size(); j++){
            if(sets[i][j] == "<"){
                //open file buffer and set it as input
                if(j == sets[i].size() - 1){
                    cout << "SYNTAX ERROR: invalid redirection use\n";
                    return false;
                }
                
                //setup file stream
                ifstream infile(sets[i][j + 1]);
                if(infile.is_open()){
                    string line;
                    while(getline(infile, line)){
                        cout << line;
                    }
                }else{
                    cout << "ERROR: Invalid file for redirection!";
                }
            }
        }

        if(sets[i][0] == "exit" || sets[i][0] == "cd"){ //exit command
            return !evalSpecial(sets[i][0], sets[i]); //if false then exit is called, or unsuccessful, terminate
        }else{ //regular command
            return !eval(sets[i][0], sets[i], fds); //if unsuccessful then terminate
        }
    }


    return false;
}

//1. Evaluate special commands
//input is the command, arguments
//returns true if successful , false otherwise or if exit detected
bool evalSpecial(string command, vector<string> args){
    if(command == "exit"){
        return false;
    }else if(command == "cd"){
        //change working directory
        if(args[1] == "-"){
            chdir("..");
        }else{
            chdir(args[1].c_str());
        }
        return true;
    }
}

//2. Evaluate normal commands
//input is the command, and vector of string arguments
//output is true if successful, or false if unsuccessful
bool eval(string command, vector<string> args, int fds[]){
    
    //run exec and wait till child is done
    int pid = fork();

    if(pid == 0){ //child process
        //convert args vector to const char **
        char *nargs[args.size()];
        for(int i = 0; i < args.size(); i++){
            nargs[i] = (char*)args[i].c_str();
        }
        nargs[args.size()] = nullptr;

        execvp(command.c_str(), nargs);
        cout << "ERROR: Command Does Not Exist!\n";
        return false;
    }else{ //parent process
        waitpid(pid, nullptr, WUNTRACED);

        return true;
    }
}